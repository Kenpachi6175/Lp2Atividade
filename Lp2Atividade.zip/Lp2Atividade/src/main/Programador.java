package main;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Programador {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Informe a quantidade de consumidores:");
        int quantidadeConsumidores = scanner.nextInt();

        List<Consumidor> consumidores = new ArrayList<>();
        for (int i = 1; i <= quantidadeConsumidores; i++) {
            System.out.println("Informe o número de registro do consumidor " + i + ":");
            int id = scanner.nextInt();

            System.out.println("Informe a demanda do consumidor " + i + ":");
            int demanda = scanner.nextInt();

            System.out.println("Informe a energia inicial do consumidor " + i + ":");
            int valorEnergia = scanner.nextInt();

            System.out.println("Informe a data da energia inicial do consumidor " + i + ":");
            int dataEnergia = scanner.nextInt();

            System.out.println("Informe o ID da energia inicial do consumidor " + i + ":");
            int idEnergia = scanner.nextInt();

            Consumidor consumidor = new Consumidor(id, demanda, valorEnergia, dataEnergia, idEnergia);
            consumidores.add(consumidor);
        }

        System.out.println("Informe a quantidade de energia a ser distribuída:");
        int valorEnergia = scanner.nextInt();

        System.out.println("Informe a data da energia a ser distribuída:");
        int dataEnergia = scanner.nextInt();

        System.out.println("Informe o ID da energia a ser distribuída:");
        int idEnergia = scanner.nextInt();

        Distribuidora distribuidora = new Distribuidora(consumidores, valorEnergia, dataEnergia, idEnergia);
        distribuidora.distribuirEnergia();

        System.out.println("------------------------");
        System.out.println("Quantidade de consumidores: " + consumidores.size());
        for (Consumidor consumidor : consumidores) {
            System.out.println("Consumidor " + consumidor.getId() + ": " + consumidor.getEnergiaConsumida());
        }
        System.out.println("------------------------");

        scanner.close();
    }
}