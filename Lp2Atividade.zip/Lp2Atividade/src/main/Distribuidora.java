package main;
import java.util.List;


public class Distribuidora extends Energia {
    private List<Consumidor> consumidores;

    public Distribuidora(List<Consumidor> consumidores, int valor, int data, int idEnergia) {
        super(valor, data, idEnergia);
        this.consumidores = consumidores;
    }

    public void distribuirEnergia() {
        int energiaDistribuida = getValor() / consumidores.size();
        for (Consumidor consumidor : consumidores) {
            consumidor.adicionarEnergia(energiaDistribuida);
        }
    }
}