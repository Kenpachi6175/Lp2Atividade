package main;

public class Consumidor extends Energia {
    private int id;
    private int demanda;
    private int energiaConsumida;

    public Consumidor(int id, int demanda, int valor, int data, int idEnergia) {
        super(valor, data, idEnergia);
        this.id = id;
        this.demanda = demanda;
    }

    // ... outros métodos e getters/setters
  

	
	    
	    public int getId() {
			return id;
		}



		public void setId(int id) {
			this.id = id;
		}



		public int getDemanda() {
			return demanda;
		}



		public void setDemanda(int demanda) {
			this.demanda = demanda;
		}



		public int getEnergiaConsumida() {
			return energiaConsumida;
		}



		public void setEnergiaConsumida(int energiaConsumida) {
			this.energiaConsumida = energiaConsumida;
		}



		public void adicionarEnergia(int energia) {
	        if (energia < 0) {
	        
	        }
	        energiaConsumida += energia;
	    }

		
		 public void adicionarEnergia() {
		        if (getValor() < 0) {
		     
		        }
		        energiaConsumida += getValor();
		    }

	 
}